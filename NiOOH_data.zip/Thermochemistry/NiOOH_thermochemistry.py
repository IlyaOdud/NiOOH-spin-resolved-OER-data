"""Spin-resolved thermochemistry of the embedded NiOOH cluster.

Final model Gibbs free energies (GFE) at 298.15 K, in Hartree (Eh),
consistent with the thermochemical approximation in manuscript v18_2.
Only the resulting GFE values are tabulated; component contributions are
not included. These are absolute embedded-cluster energies, not reaction
free energies or activation barriers. Potential-dependent electrochemical
terms are not included in the cluster values.

USAGE
    GFE_EH["a"][4]   # O* intermediate, quartet (M = 4)
    INTERMEDIATES["a"]  # chemical interpretation and geometry-folder mapping

The keys a--g identify chemical intermediates, NOT spin states.
The integer keys in GFE_EH are spin multiplicities M = 2S + 1, NOT
energy-order indices. All 38 available states are included, not only the
lowest-energy state of each intermediate.

NOTATION
EC denotes the embedded cluster. O* denotes the reactive lattice-oxygen
site. An asterisk alone (d, EC*) denotes the oxygen-vacancy state; it must
not be confused with the intact O* state (a). The appended OH, O, H, OOH,
and O2 describe the intermediate at that site; they are not separate
free molecules. See INTERMEDIATES below for each label.

PATHWAYS (chemical intermediates; each has multiple spin states)
    LOM: a -> b -> c -> d -> e -> a
    AEM: a -> b -> c -> f -> g -> a
These sequences omit solution species, electrons and released O2.
Reaction energies require balanced stoichiometry and molecular references;
absolute GFE values of different compositions must not be compared directly.

REFERENCE SPECIES
REFERENCE_GFE_EH contains the H2(g), triplet O2(g), and H2O(l) reference
values used by the same model, at 298.15 K. H2O(l) is the model's liquid-water
reference obtained with CPCM(water). Values are reported without a breakdown
into components. The standard-state convention follows the manuscript
(1 atm, 298.15 K).

Run this file with Python 3 to print the data. No third-party packages,
source outputs, or simulation software are required. Importing it performs
no calculations or file writes.
"""

TEMPERATURE_K = 298.15
ENERGY_UNIT = "Eh"
HARTREE_TO_EV = 27.2114079527

INTERMEDIATES = {
    'a': {
        "label": 'O*',
        "cluster_notation": 'ECO*',
        "geometry_folder": 'nope',
        "description": 'Unfunctionalized oxygen-centered active site; the reactive lattice oxygen is present, with no additional adsorbate.',
    },
    'b': {
        "label": 'O*OH',
        "cluster_notation": 'ECO*OH',
        "geometry_folder": 'OH',
        "description": 'Hydroxyl-containing intermediate formed by adding OH to the O* active site; common to the LOM and AEM pathways.',
    },
    'c': {
        "label": 'O*O',
        "cluster_notation": 'ECO*O',
        "geometry_folder": 'O',
        "description": 'Deprotonated oxygen-containing intermediate obtained from O*OH; the branching intermediate for the LOM and AEM pathways.',
    },
    'd': {
        "label": '*',
        "cluster_notation": 'EC*',
        "geometry_folder": 'hole',
        "description": 'Oxygen-vacancy intermediate remaining after O2 release from O*O along the LOM pathway; the reactive lattice oxygen is absent.',
    },
    'e': {
        "label": 'O*H',
        "cluster_notation": 'ECO*H',
        "geometry_folder": 'Habs',
        "description": 'Protonated lattice-oxygen intermediate formed by hydroxide addition to the vacancy; deprotonation regenerates O* along the LOM pathway.',
    },
    'f': {
        "label": 'O*OOH',
        "cluster_notation": 'ECO*OOH',
        "geometry_folder": 'OOH',
        "description": 'Hydroperoxo-containing intermediate formed by hydroxide addition to O*O along the AEM pathway.',
    },
    'g': {
        "label": 'O*O2',
        "cluster_notation": 'ECO*O2',
        "geometry_folder": 'OO',
        "description": 'Molecular-oxygen-containing intermediate obtained from O*OOH; O2 release regenerates O* along the AEM pathway.',
    },
}

# GFE_EH[intermediate][spin_multiplicity] = absolute model GFE in Eh.
GFE_EH = {
    'a': {  # O*
        2: -5524.61143866,
        4: -5524.61217696,
        6: -5524.59295907,
        8: -5524.56605303,
        10: -5524.52758983,
    },
    'b': {  # O*OH
        1: -5600.32548663,
        3: -5600.32685615,
        5: -5600.32671979,
        7: -5600.31960965,
        9: -5600.31212691,
        11: -5600.29086564,
    },
    'c': {  # O*O
        2: -5599.67703993,
        4: -5599.68189609,
        6: -5599.68084189,
        8: -5599.65349326,
        10: -5599.64971492,
    },
    'd': {  # *
        2: -5449.43782225,
        4: -5449.45685960,
        6: -5449.46122568,
        8: -5449.46021962,
        10: -5449.44862076,
    },
    'e': {  # O*H
        1: -5525.25291615,
        3: -5525.25794431,
        5: -5525.25786096,
        7: -5525.24264463,
        9: -5525.22225734,
        11: -5525.22163860,
    },
    'f': {  # O*OOH
        1: -5675.41107968,
        3: -5675.41322958,
        5: -5675.40895929,
        7: -5675.40628396,
        9: -5675.40196323,
        11: -5675.38038077,
    },
    'g': {  # O*O2
        2: -5674.81779119,
        4: -5674.79077282,
        6: -5674.76554181,
        8: -5674.81956048,
        10: -5674.76523217,
    },
}

REFERENCE_GFE_EH = {
    'H2(g)': -1.16819689,
    'O2(g), M=3': -150.22975061,
    'H2O(l)': -76.38018759,
}

# Provenance: values checked against the independently extracted state_energies.csv.
SOURCE_MODEL = 'outputs/oer_all_slurm/thermal_all_20261016_161150/NiOOHs-pro/model_data_/__init__.py'
SOURCE_MODEL_SHA256 = '4e0a6f7d7889fa36e63b7344b9273ba79a4ae66fee3c1f9b08363696c60073bb'

if __name__ == "__main__":
    print(f"T = {TEMPERATURE_K} K; absolute GFE in {ENERGY_UNIT}")
    print("Code  Intermediate  Multiplicity  GFE (Eh)")
    for code, states in GFE_EH.items():
        for mult, gfe in sorted(states.items()):
            print(f"{code:4s}  {INTERMEDIATES[code]['label']:12s}  {mult:12d}  {gfe:.8f}")
    print("\nMolecular references (Eh):")
    for species, gfe in REFERENCE_GFE_EH.items():
        print(f"{species:14s}  {gfe:.8f}")
