# Embedding-charge optimization script

Author: Ilia Odud (GitHub: IlyaOdud).

The script used for charge optimization is available in the author's repository:

[ChOpt_3_pik_4.py — Support-scripts, Charge-Optimize branch](https://github.com/IlyaOdud/Support-scripts/blob/Charge-Optimize/ChOpt_3_pik_4.py)

The script is provided by reference and is not copied into this data package.
The link points to a branch and may change as the repository is updated.

## Total charge and physical interpretation

This script has not been tested for conservation of the total system charge
during charge fitting. Adjusting the embedding charges may therefore produce
embedded clusters with a nonzero net charge or change the intended total charge.

A nonzero net embedding charge is not, by itself, evidence of an error:
charged embedding models may also be considered. However, the physical basis
and applicability of the charged embeddings produced by this procedure have
not been thoroughly investigated in this work. Their physical validity should
therefore not be inferred solely from the quality of the charge fit.

Users should check and report the resulting total charge, including the fitted
embedding charges, and assess whether the charge state is appropriate for the
physical system and modeling assumptions. Charge neutrality is not imposed
here as a universal requirement.
