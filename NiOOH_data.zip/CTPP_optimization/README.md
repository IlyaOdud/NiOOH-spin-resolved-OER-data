# CTPP optimization for the NiOOH embedding model

The CTPP parameters were optimized using a locally modified version of
`crystal_ecpexp_optimizer_slsqp.py` from the **qcldm** repository maintained by
GitHub user **dlmv**. The script is not redistributed in this package.

- [Author's script](https://github.com/dlmv/qcldm/blob/master/support/crystal_ecpexp_optimizer_slsqp.py)
- [Fixed reference version](https://github.com/dlmv/qcldm/blob/21e6fdfdd021aa4b9bc759aeda4ef14137347179/support/crystal_ecpexp_optimizer_slsqp.py)
- [Source repository and attribution](https://github.com/dlmv/qcldm)

## Included files

- `NiHO2_stag.restart`: the saved annotated CRYSTAL input containing the CTPP
  parameters and slab model. This is an optimizer restart input, not a binary
  wavefunction checkpoint. The `!F`, `!S0`, `!P0`, and `!D0` annotations identify
  parameter groups and must be retained when restarting the optimizer.
- `launch_arguments.txt`: the two optimization commands and log-copy commands
  extracted from the original job file. Machine-specific scheduler settings
  are omitted.

## Method and launch parameters

The Python script uses SciPy's SLSQP optimizer to minimize the RMS gradient
reported by CRYSTAL, adjusting grouped pseudopotential parameters in logarithmic
coordinates. Each objective evaluation launches an external CRYSTAL calculation.

The positional arguments are the input basename, finite-difference step `eps`,
and stopping tolerance `ftol`. Two successive stages were configured:

| Stage | Basename | eps | ftol |
| --- | --- | --- | --- |
| 1 | NiHO2_stag | 1e-1 | 1e-5 |
| 2 | NiHO2_stag | 1e-2 | 1e-6 |

The second stage reads the restart written by the first stage. The supplied
restart preserves the saved parameter values; it does not preserve the initial
parameters of the original optimization.

## Local changes relative to the linked author version

Comparison with the fixed reference version above found three changes:

1. The CRYSTAL launch command was replaced by a local `runcry17_pauli64_2` wrapper.
2. The logarithmic parameter bounds were widened from `[log(1/15), log(15)]`
   to `[log(1/100), log(100)]`.
3. The SLSQP iteration limit `maxiter` was increased from 30 to 100.

These changes must be reproduced to use the same optimizer settings.
Python 3, SciPy, a working CRYSTAL
installation, and a site-specific launcher are needed. No environment or
CRYSTAL execution was tested as part of preparing this archive.

## CRYSTAL version

The archived local script invokes a CRYSTAL17 launcher and recognizes the
`CRYSTAL17` banner when parsing output. The linked author version also targets
CRYSTAL17. These files therefore do not establish that this optimization was
run with CRYSTAL23.

For use with CRYSTAL23, the launcher and output parser must be adapted and
validated against CRYSTAL23 output, and the input syntax and numerical behavior
must be checked. Compatibility with CRYSTAL23 has not been tested here.
