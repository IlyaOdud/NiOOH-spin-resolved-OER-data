NiOOHs optimized embedded-cluster geometries

Contents
38 final geometries exported from the archived ORCA output directory
outputs/cluster_calculations/EMB_Cluster_water.
The source subfolder structure is retained:
Habs (6), O (5), OH (6), OO (5), OOH (6), hole (5), nope (5).
Each contains the original multN subfolders.

Extraction
Coordinates are taken from the last CARTESIAN COORDINATES (ANGSTROEM)
block before thermochemistry, after THE OPTIMIZATION HAS CONVERGED.
All 38 source outputs contain convergence and normal-termination markers.
Coordinate ordering and printed precision are preserved. No rotation,
translation, interpolation, geometry optimization, or relabeling was applied.
The mN prefix in each XYZ filename is the multiplicity reported inside the
ORCA output, not inferred from the original filename. Ten names were corrected.

XYZ comment line
EE + ZPE = <electronic energy> Eh + <zero point energy> Eh
EE is the Electronic energy in the ORCA thermochemistry block; ZPE is the
Zero point energy from the same block. The two terms are printed separately; their sum is not printed in XYZ. No entropy, thermal enthalpy, or Gibbs free-energy correction
is included. The internal extraction manifest is not included in this release.

Embedding labels and limitations
The complete printed coordinate block is retained, including boundary and
embedding centers. The first XYZ line counts all centers, including Q.
Pd is the source ORCA label for the custom boundary centers (the input uses
NewECP 46 and modified Z values); it must not be interpreted as evidence of
palladium doping of NiOOH. Q denotes a point-charge center, not a chemical
element. This source-preserving XYZ convention may require special handling
by viewers that accept only chemical element symbols.
Point-charge magnitudes, modified nuclear charges, ECP definitions, basis
sets and optimization constraints are not encoded in XYZ; the original
ORCA input and embedding definitions are needed to reproduce calculations.

Frequency qualification
All 38 source outputs report imaginary frequencies. The detailed frequency audit is not included in this release. Source ZPE values are retained
as printed by ORCA, without changing frequency treatment. Optimization
convergence alone does not establish an unconstrained minimum. These exports
are final geometries of the source calculations, not a new validation of the
frequency analysis or the complete thermodynamic model.
